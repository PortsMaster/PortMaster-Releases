This is where screen shots taken in the level editor are written.

Press the <insert> key to take a screenshot.

Three files are written out for each screen shot, a full size,
preview size, and thumbnail size.

The files are named using the same name as the map file with .png
extensions.