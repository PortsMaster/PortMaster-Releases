These sound effects were contributed by Joseph Morris  
        Joseph Morris <jpm@it-he.org>
	http://www.it-he.org

