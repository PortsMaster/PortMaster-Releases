function love.conf(t)
  t.window.title = "upo"
  t.window.icon = 'assets/icon.png'
end
