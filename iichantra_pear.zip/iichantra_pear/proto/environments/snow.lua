material = 8;

walk_vel_multiplier = 0.75;
jump_vel_multiplier = 1;
bounce_bonus = 0;

gravity_bonus_x = 0;
gravity_bonus_y = 0;

sprites =
{
	"snow-run",
	"snow-land",
	"snow-stop"
}

sounds =
{
	"snow-left.ogg",
	"snow-right.ogg",
	"stop.ogg"
}