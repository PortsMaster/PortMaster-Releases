name = "default_environment";
material = 0;

walk_vel_multiplier = 1;
jump_vel_multiplier = 1;
bounce_bonus = 0;

gravity_bonus_x = 0;
gravity_bonus_y = 0;

sprites =
{
	"dust-run",
	"dust-land",
	"dust-stop"
}

sounds =
{
	"foot-left.ogg",
	"foot-right.ogg",
	"stop.ogg"
}