--forbidden
name = "psnow";
texture = "psnow";
--FunctionName = "CreateSprite";

z = 0.05;

start_color = { 1.0, 1.0, 1.0, 1.0 };
var_color = { 0.0, 0.2, 0.0, 0.0 };
end_color = { 0.8, 1.0, 0.8, 1.0 };

max_particles = 300;
particle_life_min = 100;
particle_life_max = 300;

start_size = 4.0;
size_variability = 3.0;
end_size = 2.0;

particle_life = 60;
particle_life_var = 2;

system_life = 10;
emission = 1;