--forbidden
parent = "projectiles/explosion";

bullet_damage = 70;