--forbidden
name = "window";
texture = "window";
FunctionName = "CreateSprite";

z = -0.001;
image_width = 128;
image_height = 64;
frame_width = 78;
frame_height = 41;
frames_count = 1;
