texture = "2011lab2";

z = -0.8998;
