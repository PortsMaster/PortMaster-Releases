texture = "2011lab";

z = -0.8999;
