name = "tree2";
texture = "tree2";
FunctionName = "CreateSprite";

z = -0.005;

physic = 0;
phys_solid = 0;
phys_one_sided = 0;
phys_bullet_collidable = 0;

Animations =
{
	{
		name = "idle";
		frames =
		{
			{ dur = 100; num = 1 }
		}
	}
}