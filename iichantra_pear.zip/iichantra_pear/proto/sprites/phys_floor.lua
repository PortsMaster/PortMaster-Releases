name = "phys_floor";
texture = "phys_floor";
FunctionName = "CreateSprite";

image_width = 32;
image_height = 32;
frame_width = 32;
frame_height = 32;
frames_count = 0;

z = -0.1;

physic = 1;
phys_solid = 1;
phys_bullet_collidable = 1;
phys_one_sided = 0;

phys_max_x_vel = 3;
phys_max_y_vel = 3;
--phys_jump_vel = 20;
--phys_walk_acc = 3;