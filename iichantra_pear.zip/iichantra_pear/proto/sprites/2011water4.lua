texture = "2011tiles2";

z = -0.99;

animations =
{
	{
		name = "idle";
		frames =
		{
			{ dur = 100; num = 10 },
			{ dur = 100; num = 11 },
			{ dur = 100; num = 12 },
			{ dur = 100; num = 11 },
			{ com = constants.AnimComLoop }
		}
	}
}
