texture = "house3";

z = -0.9;
