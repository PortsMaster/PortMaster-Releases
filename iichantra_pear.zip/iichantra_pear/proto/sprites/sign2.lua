name = "sign2";
texture = "sign2";
FunctionName = "CreateSprite";

z = -0.05;

physic = 0;
phys_solid = 0;
phys_one_sided = 0;
phys_bullet_collidable = 0;