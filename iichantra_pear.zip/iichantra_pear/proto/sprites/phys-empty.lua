name = "phys-empty";
icon = "icon-start-normal";
FunctionName = "CreateSprite";

editor_color = {0.8, 0.2, 0.2, 0.5}

image_width = 1024;
image_height = 1024;
frame_width = 1;
frame_height = 1;
frames_count = 0;

z = 0;

physic = 1;
phys_solid = 1;
phys_one_sided = 0;
phys_bullet_collidable = 1;