texture = "2011lab3";

z = -0.8998;

animations =
{
	{
		name = "idle";
		frames =
		{
			{ com = constants.AnimComRealW; param = 58 },
			{ com = constants.AnimComRealH; param = 16 },
			{ com = constants.AnimComRealY; param = 2 },
			{ dur = 150; num = 67 },
			{ dur = 150; num = 70 },
			{ dur = 150; num = 71 },
			{ com = constants.AnimComLoop }
		}
	}
}
