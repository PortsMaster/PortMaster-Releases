texture = "2011tiles2";

z = -0.99;

animations =
{
	{
		name = "idle";
		frames =
		{
			{ dur = 100; num = 1 },
			{ dur = 100; num = 2 },
			{ dur = 100; num = 3 },
			{ dur = 100; num = 2 },
			{ com = constants.AnimComLoop }
		}
	}
}
