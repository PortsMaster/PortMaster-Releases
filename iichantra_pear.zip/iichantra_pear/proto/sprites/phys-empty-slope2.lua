name = "phys-empty-slope2";
icon = "icon-start-normal";
FunctionName = "CreateSprite";

image_width = 1024;
image_height = 1024;
frame_width = 1;
frame_height = 1;
frames_count = 0;

z = 0;

physic = 1;
phys_solid = 1;
phys_slope = 2;
phys_bullet_collidable = 1;
