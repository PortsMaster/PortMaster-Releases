name = "sign1";
texture = "sign1";
FunctionName = "CreateSprite";

z = -0.002;

physic = 0;
phys_solid = 0;
phys_one_sided = 0;
phys_bullet_collidable = 0;