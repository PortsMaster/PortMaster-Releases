texture = "2011lab3";

z = -0.8998;
