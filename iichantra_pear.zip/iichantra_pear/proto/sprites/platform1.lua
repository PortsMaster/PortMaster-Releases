name = "platform1";
texture = "platform1";
FunctionName = "CreateSprite";

z = -0.04;

physic = 0;
phys_solid = 0;
phys_one_sided = 0;
phys_bullet_collidable = 0;