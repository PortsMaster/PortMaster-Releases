texture = "2011tiles2";

z = -0.99;

animations =
{
	{
		name = "idle";
		frames =
		{
			{ dur = 100; num = 4 },
			{ dur = 100; num = 5 },
			{ dur = 100; num = 6 },
			{ dur = 100; num = 4 },
			{ com = constants.AnimComLoop }
		}
	}
}
