texture = "2011block";

z = -0.00005;

animations =
{
	{
		name = "idle";
		frames =
		{
			{ dur = 100; num = 4 },
		}
	}
}
