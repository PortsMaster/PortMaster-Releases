texture = "killinlazor";

z = -0.899;

animations =
{
	{
		name = "idle";
		frames =
		{
			{ dur = 50, num = 0 },
			{ dur = 50, num = 1 },
			{ constants.AnimComLoop }
		}
	}
}
