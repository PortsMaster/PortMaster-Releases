--forbidden
name = "release_sign";
texture = "hw_sign";
FunctionName = "CreateSprite";

image_width = 64;
image_height = 128;


z = -0.5;