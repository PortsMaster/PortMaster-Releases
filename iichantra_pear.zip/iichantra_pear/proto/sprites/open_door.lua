texture = "open_door";

z = -.2;
