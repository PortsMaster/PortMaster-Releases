z = 0;

physic = 1;
phys_solid = 1;
phys_slope = 1;
phys_one_sided = 1;
phys_bullet_collidable = 0;
