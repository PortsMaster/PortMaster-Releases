count = 4
main = {
	{ x = 0, y = 0, w = 64, h = 64 },		-- frame 0
	{ x = 64, y = 0, w = 64, h = 64 },		-- frame 1
	{ x = 128, y = 0, w = 64, h = 64 },		-- frame 2
	{ x = 192, y = 0, w = 64, h = 64 }		-- frame 3
}
