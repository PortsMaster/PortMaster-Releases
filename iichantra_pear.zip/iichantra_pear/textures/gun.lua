count = 2
main = {
	{ x = 0, y = 0, w = 44, h = 24 },	-- frame 0
	{ x = 0, y = 24, w = 44, h = 25 }	-- frame 1
}
