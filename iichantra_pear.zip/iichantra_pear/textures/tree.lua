count = 2
main = {
	{ x = 171, y = 2, w = 152, h = 303 },	-- frame 0
	{ x = 9, y = 2, w = 152, h = 303 }	-- frame 1
}
