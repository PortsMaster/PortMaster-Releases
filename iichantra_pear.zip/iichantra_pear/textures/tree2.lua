count = 1
main = {
	{ x = 9, y = 2, w = 152, h = 303 }	-- frame 1
}
