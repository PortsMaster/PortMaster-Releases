count = 3
main = {
	{ x = 0, y = 1, w = 21, h = 20 },	-- frame 0
	{ x = 0, y = 21, w = 21, h = 20 },	-- frame 1
	{ x = 0, y = 41, w = 21, h = 20 }	-- frame 2
}
