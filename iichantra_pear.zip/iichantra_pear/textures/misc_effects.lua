count = 9
main = {
	{ x = 0, y = 0, w = 27, h = 20 },	-- frame 0
	{ x = 26, y = 0, w = 26, h = 20 },	-- frame 1
	{ x = 52, y = 1, w = 27, h = 21 },	-- frame 2
	{ x = 79, y = 0, w = 13, h = 21 },	-- frame 3
	{ x = 93, y = 0, w = 12, h = 21 },	-- frame 4
	{ x = 105, y = 0, w = 13, h = 21 },	-- frame 5
	{ x = 1, y = 20, w = 10, h = 16 },	-- frame 6
	{ x = 12, y = 20, w = 9, h = 16 },	-- frame 7
	{ x = 22, y = 20, w = 10, h = 16 }	-- frame 8
}
