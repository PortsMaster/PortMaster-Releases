count = 8
main = {
	{ x = 0, y = 0, w = 64, h = 212 },	-- frame 0
	{ x = 65, y = 0, w = 65, h = 212 },	-- frame 1
	{ x = 130, y = 2, w = 64, h = 33 },	-- frame 2
	{ x = 194, y = 20, w = 24, h = 15 },	-- frame 3
	{ x = 129, y = 36, w = 89, h = 121 },	-- frame 4
	{ x = 129, y = 158, w = 65, h = 64 },	-- frame 5
	{ x = 219, y = 1, w = 64, h = 69 },	-- frame 6
	{ x = 219, y = 71, w = 57, h = 113 }	-- frame 7
}
