count = 1
main = {
	{ x = 0, y = 0, w = 256, h = 343 }	-- frame 0
}
