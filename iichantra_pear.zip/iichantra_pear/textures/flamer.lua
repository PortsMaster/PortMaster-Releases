count = 12
main = {
	{ x = 0, y = 0, w = 32, h = 32 },	-- frame 0
	{ x = 32, y = 0, w = 32, h = 32 },	-- frame 1
	{ x = 64, y = 0, w = 32, h = 32 },	-- frame 2
	{ x = 96, y = 0, w = 32, h = 32 },	-- frame 3
	{ x = 128, y = 0, w = 32, h = 32 },	-- frame 4
	{ x = 156, y = 0, w = 32, h = 32 },	-- frame 5
	{ x = 186, y = 0, w = 32, h = 32 },	-- frame 6
	{ x = 218, y = 0, w = 32, h = 32 },	-- frame 7
	{ x = 0, y = 31, w = 32, h = 32 },	-- frame 8
	{ x = 28, y = 31, w = 32, h = 32 },	-- frame 9
	{ x = 61, y = 31, w = 32, h = 32 },	-- frame 10
	{ x = 93, y = 31, w = 32, h = 32 }	-- frame 11
}
