count = 11
main = {
	{ x = 6, y = 9, w = 45, h = 12 },	-- frame 0
	{ x = 55, y = 8, w = 45, h = 14 },	-- frame 1
	{ x = 103, y = 3, w = 45, h = 20 },	-- frame 2
	{ x = 153, y = 1, w = 45, h = 29 },	-- frame 3
	{ x = 204, y = 1, w = 43, h = 39 },	-- frame 4
	{ x = 5, y = 26, w = 45, h = 43 },	-- frame 5
	{ x = 55, y = 26, w = 45, h = 44 },	-- frame 6
	{ x = 104, y = 26, w = 45, h = 44 },	-- frame 7
	{ x = 153, y = 33, w = 45, h = 44 },	-- frame 8
	{ x = 3, y = 75, w = 54, h = 43 },	-- frame 9
	{ x = 209, y = 65, w = 45, h = 12 }	-- frame 10
}
