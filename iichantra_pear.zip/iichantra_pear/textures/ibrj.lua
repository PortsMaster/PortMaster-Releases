count = 1
main = {
	{ x = 0, y = 0, w = 43, h = 109 }	-- frame 0
}
