count = 1
main = {
	{ x = 0, y = 0, w = 11, h = 11 }	-- frame 0
}
