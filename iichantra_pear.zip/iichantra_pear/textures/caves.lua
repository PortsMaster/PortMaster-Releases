count = 3
main = {
	{ x = 9, y = 3, w = 228, h = 122 },	-- frame 0
	{ x = 3, y = 132, w = 105, h = 93 },	-- frame 1
	{ x = 111, y = 135, w = 105, h = 92 }	-- frame 2
}
