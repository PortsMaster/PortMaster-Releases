count = 11
main = {
	{ x = 0, y = 1, w = 70, h = 153 },	-- frame 0
	{ x = 70, y = 0, w = 74, h = 157 },	-- frame 1
	{ x = 144, y = 0, w = 79, h = 157 },	-- frame 2
	{ x = 223, y = 0, w = 74, h = 156 },	-- frame 3
	{ x = 297, y = 0, w = 69, h = 153 },	-- frame 4
	{ x = 368, y = 3, w = 56, h = 141 },	-- frame 5
	{ x = 430, y = 1, w = 18, h = 149 },	-- frame 6
	{ x = 456, y = 1, w = 36, h = 148 },	-- frame 7
	{ x = 1, y = 162, w = 70, h = 153 },	-- frame 8
	{ x = 87, y = 161, w = 72, h = 153 },	-- frame 9
	{ x = 181, y = 161, w = 71, h = 154 }	-- frame 10
}
