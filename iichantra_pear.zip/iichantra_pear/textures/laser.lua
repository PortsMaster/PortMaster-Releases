count = 15
main = {
	{ x = 0, y = 0, w = 32, h = 36 },	-- frame 0
	{ x = 32, y = 0, w = 32, h = 36 },	-- frame 1
	{ x = 64, y = 0, w = 32, h = 36 },	-- frame 2
	{ x = 96, y = 0, w = 32, h = 36 },	-- frame 3
	{ x = 0, y = 36, w = 32, h = 36 },	-- frame 4
	{ x = 32, y = 36, w = 32, h = 36 },	-- frame 5
	{ x = 64, y = 36, w = 32, h = 36 },	-- frame 6
	{ x = 96, y = 36, w = 32, h = 36 },	-- frame 7
	{ x = 0, y = 72, w = 32, h = 36 },	-- frame 8
	{ x = 32, y = 72, w = 32, h = 36 },	-- frame 9
	{ x = 72, y = 72, w = 32, h = 5 },	-- frame 10
	{ x = 72, y = 78, w = 32, h = 5 },	-- frame 11
	{ x = 72, y = 84, w = 32, h = 5 },	-- frame 12
	{ x = 72, y = 90, w = 32, h = 5 },	-- frame 13
	{ x = 72, y = 96, w = 32, h = 5 }	-- frame 14
}
