count = 16
main = {
	{ x = 1, y = 2, w = 7, h = 7 },	-- frame 0
	{ x = 10, y = 2, w = 7, h = 7 },	-- frame 1
	{ x = 17, y = 1, w = 7, h = 7 },	-- frame 2
	{ x = 10, y = 2, w = 7, h = 7 },	-- frame 3
	{ x = 1, y = 2, w = 7, h = 7 },	-- frame 0
	{ x = 10, y = 2, w = 7, h = 7 },	-- frame 1
	{ x = 17, y = 1, w = 7, h = 7 },	-- frame 2
	{ x = 10, y = 2, w = 7, h = 7 },	-- frame 3
	{ x = 1, y = 2, w = 7, h = 7 },	-- frame 0
	{ x = 10, y = 2, w = 7, h = 7 },	-- frame 1
	{ x = 17, y = 1, w = 7, h = 7 },	-- frame 2
	{ x = 10, y = 2, w = 7, h = 7 },	-- frame 3
	{ x = 1, y = 2, w = 7, h = 7 },	-- frame 0
	{ x = 10, y = 2, w = 7, h = 7 },	-- frame 1
	{ x = 17, y = 1, w = 7, h = 7 },	-- frame 2
	{ x = 10, y = 2, w = 7, h = 7 }	-- frame 3
}
