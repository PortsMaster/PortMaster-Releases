count = 21
main = {
	{ x = 0, y = 0, w = 16, h = 16 },		-- frame 0
	{ x = 16, y = 0, w = 16, h = 16 },		-- frame 1
	{ x = 32, y = 0, w = 16, h = 16 },		-- frame 2
	{ x = 48, y = 0, w = 16, h = 16 },		-- frame 3
	{ x = 64, y = 0, w = 16, h = 16 },		-- frame 4
	{ x = 80, y = 0, w = 16, h = 16 },		-- frame 5
	{ x = 96, y = 0, w = 16, h = 16 },		-- frame 6
	{ x = 112, y = 0, w = 16, h = 16 },		-- frame 7
	{ x = 128, y = 0, w = 16, h = 16 },		-- frame 8
	{ x = 144, y = 0, w = 16, h = 16 },		-- frame 9
	{ x = 160, y = 0, w = 16, h = 16 },		-- frame 10
	{ x = 176, y = 0, w = 16, h = 16 },		-- frame 11
	{ x = 192, y = 0, w = 16, h = 16 },		-- frame 12
	{ x = 208, y = 0, w = 16, h = 16 },		-- frame 13
	{ x = 224, y = 0, w = 16, h = 16 },		-- frame 14
	{ x = 240, y = 0, w = 16, h = 16 },		-- frame 15
	{ x = 0, y = 16, w = 16, h = 16 },		-- frame 16
	{ x = 16, y = 16, w = 16, h = 16 },		-- frame 17
	{ x = 32, y = 16, w = 16, h = 16 },		-- frame 18
	{ x = 48, y = 16, w = 16, h = 16 },		-- frame 19
	{ x = 64, y = 16, w = 16, h = 16 }		-- frame 20
}
