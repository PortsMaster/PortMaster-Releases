count = 3
main = {
	{ x = 0, y = 0, w = 9, h = 13 },	-- frame 0
	{ x = 15, y = 0, w = 9, h = 13 },	-- frame 1
	{ x = 30, y = 0, w = 9, h = 13 }	-- frame 2
}
