count = 10
main = {
	{ x = 4, y = 1, w = 11, h = 11 },	-- frame 0
	{ x = 13, y = 1, w = 11, h = 11 },	-- frame 1
	{ x = 24, y = 1, w = 11, h = 11 },	-- frame 2
	{ x = 38, y = 1, w = 11, h = 11 },	-- frame 3
	{ x = 53, y = 1, w = 11, h = 11 },	-- frame 4
	{ x = 70, y = 0, w = 13, h = 13 },	-- frame 5
	{ x = 85, y = 1, w = 13, h = 13 },	-- frame 6
	{ x = 6, y = 15, w = 17, h = 17 },	-- frame 7
	{ x = 28, y = 15, w = 13, h = 17 },	-- frame 8
	{ x = 46, y = 15, w = 8, h = 17 }	-- frame 9
}
