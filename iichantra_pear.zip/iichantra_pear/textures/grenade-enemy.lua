count = 10
main = {
	{ x = 0, y = 0, w = 24, h = 24 },		-- frame 0
	{ x = 24, y = 0, w = 24, h = 24 },		-- frame 1
	{ x = 48, y = 0, w = 24, h = 24 },		-- frame 2
	{ x = 72, y = 0, w = 24, h = 24 },		-- frame 3
}
