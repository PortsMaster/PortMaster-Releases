count = 13
main = {
	{ x = 5, y = 6, w = 42, h = 27 },		-- frame 0
	{ x = 61, y = 6, w = 42, h = 27 },		-- frame 1
	{ x = 117, y = 6, w = 42, h = 27 },		-- frame 2
	{ x = 173, y = 6, w = 42, h = 27 },		-- frame 3
	{ x = 229, y = 6, w = 42, h = 27 },		-- frame 4
	{ x = 286, y = 6, w = 42, h = 27 },		-- frame 5
	{ x = 5, y = 35, w = 42, h = 27 },		-- frame 6
	{ x = 61, y = 35, w = 42, h = 27 },		-- frame 7
	{ x = 117, y = 35, w = 42, h = 27 },		-- frame 8
	{ x = 173, y = 35, w = 42, h = 27 },		-- frame 9
	{ x = 229, y = 35, w = 42, h = 27 },		-- frame 10
	{ x = 285, y = 35, w = 42, h = 27 },		-- frame 11
	{ x = 273, y = 11, w = 13, h = 25 }		-- frame 12
}
