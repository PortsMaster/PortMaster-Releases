count = 27
main = {
	{ x = 1, y = 1, w = 13, h = 13 },	-- frame 0
	{ x = 16, y = 1, w = 13, h = 13 },	-- frame 1
	{ x = 31, y = 1, w = 13, h = 13 },	-- frame 2
	{ x = 46, y = 1, w = 13, h = 13 },	-- frame 3
	{ x = 1, y = 16, w = 13, h = 13 },	-- frame 4
	{ x = 16, y = 16, w = 13, h = 13 },	-- frame 5
	{ x = 1, y = 33, w = 13, h = 13 },	-- frame 6
	{ x = 16, y = 33, w = 17, h = 17 },	-- frame 7
	{ x = 36, y = 33, w = 21, h = 21 },	-- frame 8
	{ x = 31, y = 16, w = 5, h = 5 },	-- frame 9
	{ x = 38, y = 16, w = 5, h = 7 },	-- frame 10
	{ x = 45, y = 16, w = 5, h = 5 },	-- frame 11
	{ x = 52, y = 16, w = 7, h = 5 },	-- frame 12
	{ x = 31, y = 25, w = 5, h = 5 },	-- frame 13
	{ x = 38, y = 25, w = 5, h = 7 },	-- frame 14
	{ x = 45, y = 25, w = 5, h = 5 },	-- frame 15
	{ x = 52, y = 25, w = 7, h = 5 },	-- frame 16
	{ x = 1, y = 47, w = 7, h = 7 },	-- frame 17
	{ x = 1, y = 55, w = 7, h = 7 },	-- frame 18
	{ x = 9, y = 47, w = 7, h = 7 },	-- frame 19
	{ x = 9, y = 55, w = 7, h = 7 },	-- frame 20
	{ x = 17, y = 51, w = 5, h = 5 },	-- frame 21
	{ x = 17, y = 57, w = 5, h = 5 },	-- frame 22
	{ x = 23, y = 51, w = 5, h = 5 },	-- frame 23
	{ x = 23, y = 57, w = 5, h = 5 },	-- frame 24
	{ x = 34, y = 56, w = 7, h = 5 },	-- frame 25
	{ x = 42, y = 56, w = 7, h = 5 }	-- frame 26
}
