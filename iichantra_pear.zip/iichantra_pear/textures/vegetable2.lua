count = 16
main = {
	{ x = 0, y = 0, w = 21, h = 31 },	-- frame 0
	{ x = 21, y = 0, w = 21, h = 31 },	-- frame 1
	{ x = 42, y = 0, w = 21, h = 31 },	-- frame 2
	{ x = 63, y = 0, w = 21, h = 31 },	-- frame 3
	{ x = 0, y = 31, w = 21, h = 31 },	-- frame 4
	{ x = 21, y = 31, w = 21, h = 31 },	-- frame 5
	{ x = 42, y = 31, w = 21, h = 31 },	-- frame 6
	{ x = 63, y = 31, w = 21, h = 31 },	-- frame 7
	{ x = 0, y = 62, w = 21, h = 31 },	-- frame 8
	{ x = 21, y = 62, w = 21, h = 31 },	-- frame 9
	{ x = 42, y = 62, w = 21, h = 31 },	-- frame 10
	{ x = 63, y = 62, w = 21, h = 31 },	-- frame 11
	{ x = 0, y = 93, w = 21, h = 31 },	-- frame 12
	{ x = 21, y = 93, w = 21, h = 31 },	-- frame 13
	{ x = 42, y = 93, w = 21, h = 31 },	-- frame 14
	{ x = 63, y = 93, w = 21, h = 31 },	-- frame 15
}