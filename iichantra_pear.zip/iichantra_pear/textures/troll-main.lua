count = 6
main = {
	{ x = 0, y = 0, w = 127, h = 185 },	-- frame 0
	{ x = 127, y = 0, w = 130, h = 185 },	-- frame 1
	{ x = 256, y = 0, w = 134, h = 185 },	-- frame 2
	{ x = 0, y = 186, w = 133, h = 186 },	-- frame 3
	{ x = 134, y = 187, w = 133, h = 186 },	-- frame 4
	{ x = 267, y = 187, w = 134, h = 186 },	-- frame 5
}
