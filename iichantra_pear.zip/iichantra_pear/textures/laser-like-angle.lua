count = 10
main = {
	{ x = 0, y = 0, w = 32, h = 64 },		-- frame 0
	{ x = 0, y = 64, w = 32, h = 64 },		-- frame 1
	{ x = 0, y = 128, w = 32, h = 64 },		-- frame 2
	{ x = 0, y = 192, w = 32, h = 64 },		-- frame 3
	{ x = 0, y = 256, w = 32, h = 64 },		-- frame 4
	{ x = 0, y = 320, w = 32, h = 64 },		-- frame 5
	{ x = 0, y = 384, w = 32, h = 64 },		-- frame 6
	{ x = 0, y = 448, w = 32, h = 64 },		-- frame 7
	{ x = 0, y = 512, w = 32, h = 64 },		-- frame 8
	{ x = 0, y = 576, w = 32, h = 64 }		-- frame 9
}
