count = 19
main = {
	{ x = 0, y = 0, w = 32, h = 32 },		-- frame 0
	{ x = 32, y = 0, w = 32, h = 32 },		-- frame 1
	{ x = 64, y = 0, w = 32, h = 32 },		-- frame 2
	{ x = 96, y = 0, w = 32, h = 32 },		-- frame 3
	{ x = 128, y = 0, w = 32, h = 32 },		-- frame 4
	{ x = 160, y = 0, w = 32, h = 32 },		-- frame 5
	{ x = 192, y = 0, w = 32, h = 32 },		-- frame 6
	{ x = 224, y = 0, w = 32, h = 32 },		-- frame 7
	{ x = 0, y = 32, w = 32, h = 32 },		-- frame 8
	{ x = 32, y = 32, w = 32, h = 32 },		-- frame 9
	{ x = 64, y = 32, w = 32, h = 32 },		-- frame 10
	{ x = 96, y = 32, w = 32, h = 32 },		-- frame 11
	{ x = 128, y = 32, w = 32, h = 32 },		-- frame 12
	{ x = 160, y = 32, w = 32, h = 32 },		-- frame 13
	{ x = 192, y = 32, w = 32, h = 32 },		-- frame 14
	{ x = 224, y = 32, w = 32, h = 32 },		-- frame 15
	{ x = 0, y = 64, w = 32, h = 32 },		-- frame 16
	{ x = 32, y = 64, w = 32, h = 32 },		-- frame 17
	{ x = 64, y = 64, w = 32, h = 32 }		-- frame 18
}
