count = 4
main = {
	{ x = 0, y = 0, w = 8, h = 8 },	-- frame 0
	{ x = 8, y = 0, w = 8, h = 8 },	-- frame 1
	{ x = 0, y = 8, w = 8, h = 8 },	-- frame 2
	{ x = 8, y = 8, w = 8, h = 8 }	-- frame 3
}
