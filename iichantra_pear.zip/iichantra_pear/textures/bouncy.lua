count = 10
main = {
	{ x = 5, y = 5, w = 16, h = 16 },	-- frame 0
	{ x = 20, y = 5, w = 16, h = 16 },	-- frame 1
	{ x = 36, y = 5, w = 16, h = 16 },	-- frame 2
	{ x = 7, y = 23, w = 13, h = 13 },	-- frame 3
	{ x = 23, y = 23, w = 17, h = 17 },	-- frame 4
	{ x = 4, y = 39, w = 21, h = 21 },	-- frame 5
	{ x = 29, y = 42, w = 19, h = 19 },	-- frame 6
	{ x = 5, y = 66, w = 19, h = 19 },	-- frame 7
	{ x = 31, y = 69, w = 15, h = 15 },	-- frame 8
	{ x = 8, y = 90, w = 15, h = 15 }	-- frame 9
}
