v1.22

Esta traducción al español del Cave Story ha sido realizada por Orden.
Puedes poner esta  traducción donde quieras, pero sin ánimos de lucro o diciendo que es tuya.

Para jugar ejecuta Doukutsu.exe
Para cambiar las opciones abre DoConfig.exe

Los controles son:
Flechas de dirección: moverse
Z: saltar / aceptar
A: cambiar al arma anterior
S: cambiar al arma siguiente
X: disparar
Q: inventario
Esc: menú

Esta traducción está hecha para Windows, aunque se puede jugar en cualquier port de Cave Story. Simplemente sustituye la carpeta data de tu Cave Story por la de éste. Debería funcionar sin problemas, aunque los nombres de los lugares quizá no salgan traducidos.

Cualquier fallo o sugerencia enviádmelo a aitoreitor@gmail.com

Muchísimas gracias a Pixel por este maravilloso juego y a Aeon Genesis por la cuidada traducción al inglés, en la cual me basé para hacer ésta al español.

----------------------

Cambios:

07/11/2009 - v1.0
- Menús y cosas varias traducidas al completo.
- Lo único que no está traducido es ARMS, ITEMS, WARP, Level Up!, Level Down y Empty!. De momento no tengo pensado traducirlos, más que nada por las limitaciones de espacio por el hecho de que son sprites y no "texto". Las tres últimas serían posibles aunque algo complicadas.
- Textos completamente traducidos.

08/11/2009 - v1.01
- Corregido el 'Artesano Ermitaño'.
- Quitada una 'a' de más en la Carta de Sue.

16/11/2009 - v1.2
- Traducidas dos frases que me había saltado.
- Manual traducido.
- Readme original traducido (ahora es Léeme).
- Créditos traducidos.
- Absolutamente todo excepto ARMS, ITEMS, WARP, Level Up!, Level Down y Empty! está traducido. Las aplicaciones DoConfig.exe y OrgView.exe no cuentan, ya que son una historia aparte y requieren conocimientos que no tengo.

23/11/2009 - v1.21
- Traducidos los gráficos que faltaban (ARMS, ITEMS, etc.).
- Traducido cierto diálogo que se me pasó por alto.
- Corregidos dos fallos y mejoradas dos expresiones.
