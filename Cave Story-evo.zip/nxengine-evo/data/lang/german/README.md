# Improved 2018 German translation for nxengine-evo
## Note: this repo is for translators only. Ready to use translations are in https://github.com/nxengine/translations

Translated by Reality Dreamers

http://www.reality-dreamers.de/ / https://rd.mangadex.com/
