# Russian translation for nxengine-evo
## Note: this repo is for translators only. Ready to use translations are are in https://github.com/nxengine/translations

Script translations are from Шедевр.  
Graphics are from tag-team / lupus.

Sadly, tag-team translation is better, but unusable (it uses runglish, e.g. maps russian chars to english ones).  
So feel free to improve.
